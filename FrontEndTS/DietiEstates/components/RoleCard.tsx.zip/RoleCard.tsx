import React, { useEffect } from 'react';
import { TouchableOpacity } from 'react-native';
import { ThemedText } from '@/components/ThemedText';
import { useThemeColor } from '@/hooks/useThemeColor';
import { ThemedIcon } from './ThemedIcon';

interface RoleCardProps {
  title: string;
  description: string;
  iconUrl: string;
  onSelect: () => void;
  accessibilityLabel: string;
  iconSize?: number; // Aggiungi questa proprietà
}

export const RoleCard: React.FC<RoleCardProps> = ({
  title,
  description,
  iconUrl,
  onSelect,
  accessibilityLabel,
  iconSize = 48 // Dimensione predefinita dell'icona
}) => {
  const backgroundColor = useThemeColor({ light: undefined, dark: undefined }, 'roleCardBackground');
  const textColor = useThemeColor({ light: undefined, dark: undefined }, 'roleCardText');

  useEffect(() => {
    console.log('RoleCard rendered with:', {
      title,
      description,
      iconUrl,
      backgroundColor,
      textColor,
    });
  }, [title, description, iconUrl, backgroundColor, textColor]);

  return (
    <TouchableOpacity
      onPress={onSelect}
      accessible={true}
      accessibilityLabel={accessibilityLabel}
      accessibilityRole="button"
      className="flex flex-col items-center p-8 rounded-lg border border-solid transition-all translate-y-0 cursor-pointer duration-[0.2s] ease-[ease] shadow-[0px_4px_8px_rgba(0,0,0,0.1)]"
      style={{ backgroundColor }}
    >
      <ThemedIcon
        icon={iconUrl}
        size={iconSize} // Passa la dimensione dell'icona
        accessibilityLabel={`Icon for ${title}`}
      />
      
      <ThemedText type='subtitle' className="text-4xl font-bold" lightColor={textColor} darkColor={textColor}>
        {title}
      </ThemedText>
      <ThemedText type='description' className="text-sm font-light text-opacity-80" lightColor={textColor} darkColor={textColor}>
        {description}
      </ThemedText>
    </TouchableOpacity>
  );
};